package application;
/*
 * Abstract class, an object that chooses moves to perform.
 */
public interface Player {
	int GetMove(int[] moves);
}