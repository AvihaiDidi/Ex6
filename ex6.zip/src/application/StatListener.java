package application;

public interface StatListener {

	void updateStat(int curPlayer, int p1Score, int p2Score);
	
}
